# Hacksprint_W5
Development of a study group web app that connects students with study groups
